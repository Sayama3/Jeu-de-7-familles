------------------------------------ Getting Started ------------------------------------

Open up the Getting Started guide from "Tools > Odin Inspector > Getting Started."


------------------------------------- Helpful Links -------------------------------------

Tutorials:          https://odininspector.com/tutorials
API Documentaion:   https://odininspector.com/documentation
Roadmap:            https://odininspector.com/roadmap
Release Notes:      https://odininspector.com/patch-notes
Issue Tracker:      https://bitbucket.org/sirenix/odin-inspector


--------------------------------- Community and Support ---------------------------------

If you have any issues, suggestions or want advice, then you're more than welcome 
to join us on Discord, or reach out to us by any other means.

Support:            https://odininspector.com/support
Community Addons:   https://odininspector.com/community-tools
Discord:            https://discord.gg/AgDmStu


---------------------------------------Thanks you!---------------------------------------

We really hope you like using Odin. Be sure to leave a review on the Asset Store,
that helps us out a lot!

Leave a review:     https://assetstore.unity.com/packages/tools/utilities/odin-inspector-and-serializer-89041


Odin Inspector is published by Devdog and developed by Sirenix.

Devdog:             https://devdog.io
Sirenix:            Https://sirenix.net